from django.contrib import admin

from .models import ActivityLog

admin.site.register(ActivityLog)
