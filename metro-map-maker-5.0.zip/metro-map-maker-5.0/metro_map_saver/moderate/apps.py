from django.apps import AppConfig


class ModerateConfig(AppConfig):
    name = 'moderate'
